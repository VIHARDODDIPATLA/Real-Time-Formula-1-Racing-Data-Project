# Databricks notebook source
# MAGIC %sql
# MAGIC SELECT * FROM v_race_results

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC   FROM global_temp.gv_race_results;

# COMMAND ----------

